
app.controller("AfrCare", function(){
	var afr = this;
});